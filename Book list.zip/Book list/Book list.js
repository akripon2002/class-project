var type= new type(".text",{
    Strings:["Frontent Developer", "YouTuber", "Web Developer"],
    typeSpeed:100,
    backSpeed:100,
    backDelay:1000,
    loop:true
});
